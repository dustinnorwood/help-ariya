{-# LANGUAGE OverloadedStrings #-}

module Main where

import qualified Data.ByteString as BS
import qualified Data.ByteString.Char8 as C8
import qualified Data.ByteString.Base16 as B16
import Crypto.Saltine.Class (decode, encode)
import Crypto.Saltine.Core.SecretBox as SB
import Crypto.Saltine.Internal.SecretBox (Key(..), Nonce(..))
import Crypto.Hash (hash)
import Crypto.Hash.Algorithms (SHA256)
import Data.ByteArray (convert)
import System.Environment (getArgs)

-- Derive a SecretBox key using a password and a salt
deriveKey :: BS.ByteString -> BS.ByteString -> Key
deriveKey password salt =
  let h = hash (BS.append password salt) :: Crypto.Hash.Digest SHA256
  in Key (convert h)

-- Hex decode with validation
decodeHex :: String -> BS.ByteString
decodeHex s =
  let (bs, rest) = B16.decode (C8.pack s)
  in if BS.null rest then bs else error "Invalid hex input"

-- Convert ByteString to hex-encoded string
encodeHex :: BS.ByteString -> String
encodeHex = C8.unpack . B16.encode

main :: IO ()
main = do
  args <- getArgs
  case args of
    [saltHex, nonceHex, cipherHex] -> do
      let salt     = decodeHex saltHex
          nonceBs  = decodeHex nonceHex
          cipherBs = decodeHex cipherHex
          password = "Bl0ck@pps123"  -- Replace with your password source

      -- Convert nonce
      nonce <- case decode nonceBs :: Maybe Nonce of
        Just n  -> return n
        Nothing -> error "Invalid nonce"

      -- Derive key
      let key = deriveKey password salt

      -- Decrypt
      case open key nonce cipherBs of
        Just plaintext -> putStrLn $ encodeHex plaintext
        Nothing        -> error "Decryption failed"
    _ -> putStrLn "Usage: program <hexSalt> <hexNonce> <hexCiphertext>"
